
import React from "react";
import CourseCards from "../components/CourseCards"

const Home: React.FC = () => {
    return (
        <>
            <CourseCards/>
        </>
    );
};


export default Home;

