
import React from "react";
import DetailBlogPost from "../components/DetailBlogPost"

const BlogDetail: React.FC = () => {
    return (
        <>
           <DetailBlogPost/>
        </>
    );
};


export default BlogDetail;