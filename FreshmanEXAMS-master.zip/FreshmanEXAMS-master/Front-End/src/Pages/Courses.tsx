
import React from "react";
import AllCourseCards from "../components/AllCourseCards"

const Courses: React.FC = () => {
    return (
        <>
            <AllCourseCards/>
        </>
    );
};


export default Courses;