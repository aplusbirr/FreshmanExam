
import React from "react";

const Admin: React.FC = () => {
    return (
        <>
            
        </>
    );
};


export default Admin;
