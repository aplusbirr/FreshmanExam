
import React from "react";

const About: React.FC = () => {
    return (
        <>
            
        </>
    );
};


export default About;
