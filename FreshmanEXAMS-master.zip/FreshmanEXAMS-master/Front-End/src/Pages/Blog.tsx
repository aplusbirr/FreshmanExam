
import React from "react";
import BlogPost from "../components/BlogPost.tsx"

const Blog: React.FC = () => {
    return (
        <>
            <BlogPost/>
        </>
    );
};


export default Blog;