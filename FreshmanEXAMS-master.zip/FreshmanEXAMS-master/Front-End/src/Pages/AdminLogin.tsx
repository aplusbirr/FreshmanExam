
import React from "react";

const AdminLogin: React.FC = () => {
    return (
        <>
            
        </>
    );
};


export default AdminLogin;