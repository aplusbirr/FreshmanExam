
import React from "react";

const Contact: React.FC = () => {
    return (
        <>
        
        </>
    );
};


export default Contact;