
import React from "react";

const UserRegister: React.FC = () => {
    return (
        <>
            
        </>
    );
};


export default UserRegister;