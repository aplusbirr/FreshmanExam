
import React from "react";
import Header from "../components/Header.tsx"

const BlogPost: React.FC = () => {
    return (
        <>
            <Header/>
        </>
    );
};


export default BlogPost;