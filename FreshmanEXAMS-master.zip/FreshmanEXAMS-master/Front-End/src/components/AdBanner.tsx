
import React from "react";

const AdBanner: React.FC = () => {
    return (
        <>
            
            <div className="AdBanner d-flex justify-content-center align-items-center">AdBanner</div>
            
        </>
    );
};


export default AdBanner;

